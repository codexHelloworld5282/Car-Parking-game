package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;

// Defines a class 'ParkingLot' that extends JComponent
class ParkingLot extends JComponent {
    // Defines the number of parking spaces as a constant variable
    private static final int NUM_SPACES = 10;
    // Defines the width of each parking space as a constant variable
    private static final int SPACE_WIDTH = 75;
    // Defines the height of each parking space as a constant variable
    private static final int SPACE_HEIGHT = 50;

    // Overrides the paintComponent method of JComponent to draw the parking spaces
    @Override
    public void paintComponent(Graphics g) {
        // Creates a Graphics2D object for drawing the parking spaces
        Graphics2D g2 = (Graphics2D) g;

        // Iterates through each parking space
        for (int i = 0; i < NUM_SPACES; i++) {
            int X = 0;
            int Y = i * SPACE_HEIGHT;
            // Sets the color of the parking space to gray
            g2.setColor(Color.GRAY);
            // Fills in the parking space with the gray color
            g2.fillRect(X, Y, SPACE_WIDTH, SPACE_HEIGHT);
            // Sets the color of the parking space border to black
            g2.setColor(Color.BLACK);
            // Draws the border of the parking space with the black color
            g2.drawRect(X, Y, SPACE_WIDTH, SPACE_HEIGHT);
            // Sets the color of the parking space number to white
            g2.setColor(Color.WHITE);
            // Sets the font of the parking space number to Arial, bold, and size 12
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            // Draws the parking space number in the middle of the parking space
            g2.drawString(String.valueOf(i + 1), X + SPACE_WIDTH/4, Y + SPACE_HEIGHT/2);
        }
    }
    // Overrides the getPreferredSize method of JComponent
    @Override
    public Dimension getPreferredSize() {
        // Returns the preferred size of the component
        return new Dimension(SPACE_WIDTH, NUM_SPACES * SPACE_HEIGHT);
    }
}

public class ParkingFrame extends JFrame implements ActionListener{
    // Declare JLabel variables for the car, parking area, time label, and parking track
    JLabel car, Area, timeLabel, trackParking;

    // Declare int variables for the initial x and y position of the car, and for the minutes and seconds on the timer
    int x = 500;
    int y = 200;
    int min = 0;
    int sec = 0;

    // Declare int variables for the x and y position of the rectangle
    int rectX = 0, rectY = 0;

    // Declare an ImageIcon variable for the car icon
    ImageIcon icon;

    // Declare JButton variables for the reset button, park car button, and start timer button
    JButton resetButton, ParkCar, startTimer;

    // Declare a Point variable for the initial location of the car
    Point initialLocation = new Point(x, y);

    // Declare a String array variable
    String[] num;

    // Declare a Timer variable
    Timer timer;

    // Declare a String variable
    String n;

    // Declare an Object variable
    Object option;

    // Constructor for the ParkingFrame class
    public ParkingFrame() {
       // Set the car icon and scale it to the desired size

        //First we have created a folder with name images
        //That folder contains the image of car top view
        //The whole path of the image is copied and placed in theImageIcon constructor
        //REMEMBER IF YOU ARE OPERATING PROJECT IN DIFF PATH THEN COPY THE PATH OF IMAGE AND
        //PLACE IT HERE WITH THE NAME OF IMAGE AND EXTENSION .png
        //OTHERWISE NO IMAGE WILL BE DISPLAYED
        icon = new ImageIcon("C:\\Users\\HP\\IdeaProjects\\Test1\\images\\car.png");
        Image image = icon.getImage();
        Image newImage = image.getScaledInstance(75, 50, Image.SCALE_SMOOTH);
        icon = new ImageIcon(newImage);

        car = new JLabel(icon); // creates a label with the car icon
        car.setBounds(x,y,75,50); // sets the bounds of the label (x, y, width, height)
        add(car); // adds the label to the frame
        setFocusable(true);


        // Set up the key bindings for the label
        InputMap inputMap = car.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actionMap = car.getActionMap();

        inputMap.put(KeyStroke.getKeyStroke("UP"), "moveUp");
        actionMap.put("moveUp", new MoveAction(0, -10));

        inputMap.put(KeyStroke.getKeyStroke("DOWN"), "moveDown");
        actionMap.put("moveDown", new MoveAction(0, 10));

        inputMap.put(KeyStroke.getKeyStroke("LEFT"), "moveLeft");
        actionMap.put("moveLeft", new MoveAction(-10, 0));

        inputMap.put(KeyStroke.getKeyStroke("RIGHT"), "moveRight");
        actionMap.put("moveRight", new MoveAction(10, 0));

        // Creates a reset button and adds it to the frame
        resetButton=new JButton("RESET");
        resetButton.setBounds(480,300,100,25);
        //Adding action listener to perform respective task
        resetButton.addActionListener(this);
        add(resetButton);

        // Creates a "Park Car" button and adds it to the frame
        ParkCar=new JButton("PARK CAR");
        ParkCar.setBounds(480,350,100,25);
        //Adding action listener to perform respective task
        ParkCar.addActionListener(this);
        add(ParkCar);

        // Creates a Label and adds it to the frame
        Area=new JLabel("The selected area to park the car is : ");
        //Changing the size and font of label
        Area.setFont(new Font("Times new roman",Font.BOLD,15));
        Area.setBounds(315,20,280,50);
        add(Area);



        //Creates a label to display time
        timeLabel = new JLabel("00:00");
        //calling function set time
        setTimer();

        // Creating a new JLabel "timeLabel" and setting its font to "Times New Roman" in bold with a size of 20
        timeLabel.setFont(new Font("Times new roman",Font.BOLD,20));
// Setting the position of the label on the frame using "setBounds" method and passing the x,y
// coordinates and width, height of the label
        timeLabel.setBounds(500,400,100,30);
// Adding the label to the frame
        add(timeLabel);

//Creating a new JLabel "trackParking" and setting its font to "Times New Roman" in bold with a size of 30
        trackParking=new JLabel();
        trackParking.setBounds(100,180,500,100);
        trackParking.setFont(new Font("Times new roman",Font.BOLD,30));
        add(trackParking);

//Creating a JButton "startTimer" and adding an action listener to it.
        startTimer = new JButton("Start Timer");
        startTimer.addActionListener(this);
        startTimer.setBounds(480,450,100,25);
        add(startTimer);

// Setting the default close operation of the frame to exit the program when the "X" button is clicked
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
// Setting the size and position of the frame on the screen
        setBounds(500, 100, 600, 545);

// Calling the instruction() and parkingArea() methods
        instruction();
        parkingArea();

// Adding a new ParkingLot object to the frame
        add(new ParkingLot());
// Setting the location of the frame to be in the center of the screen
        setLocationRelativeTo(null);

        //Setting the title of frame
        setTitle("CAR PARKING APPLICATION");

// Making the frame visible on the screen
        setVisible(true);

    }

    // method that displays instructions for using the parking lot program
    public void instruction()
    {
        JOptionPane.showOptionDialog(null, """
                        1.Select the Number where you want to park the car
                        2.Make sure to press OK button for selection
                        3.You can move the car with help of arrow keys
                        4.Press RESET button to reset car position and timer
                        5.After getting to the place where you want to park the car press PARK CAR
                        6.You can resume timer by again pressing START TIMER
                        7.Press close "X" to continue!""", "Instructions",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, new Object[]{}, null);
    }

    // method that sets the timer for the parking lot program
    public void setTimer()
    {
        // create and set the timer
        timer = new Timer(1000, e -> {
            sec++;
            if (sec == 60) {
                min++;
                sec= 0;
            }
            timeLabel.setText(String.format("%02d:%02d", min, sec));
        });

    }
    // method that allows user to select a parking area
    public void parkingArea()
    {
        num=new String[]{"null","1","2","3","4","5","6","7","8","9","10"};
        option=JOptionPane.showInputDialog(this, "Select parking area", "PARKING LOT NUMBER",
                JOptionPane.QUESTION_MESSAGE,
                null, num, num[0]);
        n= (String) option;
        if (option=="null")
        {
            JOptionPane.showInputDialog(this, "Please make valid selection from 1 to 10",
                    "Warning",
                    JOptionPane.WARNING_MESSAGE,
                    null, num ,null);
        }
        else {
            Area.setText(Area.getText()+option);
        }
    }

    // Action for moving the label
    private class MoveAction extends AbstractAction {
        private final int x;
        private final int y;

        public MoveAction(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public void actionPerformed(ActionEvent e) {
            Point location = car.getLocation();
            car.setLocation(location.x + x, location.y + y);
        }
    }

        public static void main(String[] args) {
            EventQueue.invokeLater(() -> {
                ParkingFrame frame = new ParkingFrame();
                frame.setVisible(true);});

        }


    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==startTimer)
            timer.start();
        if (e.getSource()==ParkCar)
        {
            boolean flag=false;
            int carX = car.getX();
            int carY = car.getY() ;

            timer.stop();
            // Iterate through the rectangles and check if any of them contain the car image
            for (int i = 0; i < 10; i++) {

                int check=Integer.parseInt(n);
                rectY=i*50;
                if (rectY==carY&&rectX==carX&&check==i+1) {
                    trackParking.setText("CAR PARKED CORRECTLY!!");
                    trackParking.setForeground(Color.GREEN);
                    flag=true;
                }
            }
            if (!flag)
            {
                trackParking.setText("WRONG PARKING!!");
                trackParking.setForeground(Color.RED);
            }
            }

        if (e.getSource()==resetButton)
        {
            car.setLocation(initialLocation);
            min=0;
            sec=0;
            timeLabel.setText("00:00");
            parkingArea();
            Area.setText("The selected area to park the car is : "+option);
            trackParking.setText(" ");
        }
    }

}
